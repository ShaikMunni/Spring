package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Product;
import com.cg.spring.mvc.repository.IProductRepo;
@Component
public class ProductServiceImpl implements IProductService {

	//IProductRepo pro=new ProductRepoImpl();//no need to create instance ,we just have to inject instance which is created by spring using autowired
	@Autowired
	IProductRepo repo;
	public List<Product> getAllProducts() {
		
		return repo.getAllProducts();
	}
	public void add(Product p) {
		repo.add(p);
		
	}
	public Product searchProduct(int id) {
		
		return repo.searchProduct(id);
	}
}
