package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Product;

@Component
public class ProductRepoImpl implements IProductRepo{
	List<Product> list=new ArrayList();
	public List<Product> getAllProducts() {
		return list;
		
	}
	public void add(Product p) {
		Product p1=new Product();
		/*p1.setId(list.size()+1);
		p1.setName("iphone 6s");
		p1.setPrice(9800);
		list.add(p1);
		Product p2=new Product();
		p2.setId(list.size()+1);
		p2.setName("samsung galaxy s4");
		p2.setPrice(8900);
		list.add(p2);*/
		p.setId(list.size()+1);
		list.add(p);
		
	}
	
	public Product searchProduct(int id) {
		
			for(Product l:list)
			{
				if(l.getId()==id)
				{
					return l;
				}
			}
		
		return null;
	}
	
	

}
