package com.cg.spring.mvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller//hellocontroller is controoler for application
public class HelloController {
	//mapping request to RequestMethod nd type of request is GET
	@RequestMapping(value="/hello",method=RequestMethod.GET)
	public String sayHello()
	{
		return "success";//controller will return with an extension .jsp===>success.jsp
	}
	
}
