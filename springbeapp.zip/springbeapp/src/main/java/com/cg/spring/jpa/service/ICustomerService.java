package com.cg.spring.jpa.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.jpa.bean.Customer;

@Service
public interface ICustomerService {

	public List<Customer> getAll();
	public void addCustomer(Customer c);
	public Customer searchById(Integer id);
	public void deleteById(int id);
	public void updateById(Customer c);
}
