package com.cg.spring.jpa.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.spring.jpa.bean.Customer;
import com.cg.spring.jpa.service.ICustomerService;

@RestController
public class CustomerRestController {
	
	@Autowired
	ICustomerService service;
	@RequestMapping(value="/getall",method=RequestMethod.GET)
	public List<Customer> getAll()
	{
		return service.getAll();
		
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	public String add(@RequestBody Customer c)
	{
		
		service.addCustomer(c);
		return "added";
	}
	@RequestMapping(value="/search")
	public Customer searchById(@PathVariable("id") Integer id)
	{
		
		return service.searchById(id);
	}
	@RequestMapping(value="/delete")
	public String deleteById(@RequestBody Integer id)
	{
				 service.deleteById(id);
				 return "customer deleted";
				
	}
	@RequestMapping(value="/update",method=RequestMethod.POST)
	public String updateById(@RequestBody Customer c)
	{
		service.updateById(c);
		return "updated";
	}
}
