package com.cg.spring.jpa.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.spring.jpa.bean.Customer;
import com.cg.spring.jpa.repository.ICustomerRepo;

@Component
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	ICustomerRepo repo;
	
	
	@Override
	public List<Customer> getAll() {
		List<Customer> list=new ArrayList();
		repo.findAll().forEach(list::add);
		return list;
	}
	@Override
	public void addCustomer(Customer c) {
		repo.save(c);
		
	}
	@Override
	public Customer searchById(Integer id) {
		return repo.findOne(id);
		
		
	}
	@Override
	public void deleteById(int id) {
		
		
		repo.delete(id);
		
		
	}
	@Override
	public void updateById(Customer c) {
	Customer c1=repo.findOne(c.getId());
	c1.setCity(c.getCity());
	c1.setCname(c.getCname());
	c1.setMailid(c.getMailid());
	repo.save(c1);
		
		
		
	}

}
