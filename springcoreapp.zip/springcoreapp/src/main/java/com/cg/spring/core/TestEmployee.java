package com.cg.spring.core;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmployee {

	public static void main(String[] args) {
		ConfigurableApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		//ApplicationContext context=new ClassPathXmlApplicationContext("spring.xml");
		/*Employee e1=new Employee();
		
		System.out.println(e1);*/
		
		//Employee e1=context.getBean(Employee.class);
		Employee e1=(Employee)context.getBean("emp");
		Manager m=context.getBean(Manager.class);
	//	e1.setId(161003);
		//e1.setName("munni");
		//e1.setSalary(20000.00);
	//	System.out.println(e1);
		/*m.setDeptno(101);
		m.setPname("XYZ");
		m.setPcode("1212123");*/
		//System.out.println(m);
		context.close();
	}

}
