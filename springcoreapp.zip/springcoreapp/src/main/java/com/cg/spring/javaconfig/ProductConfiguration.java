package com.cg.spring.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration//bean decleration as in xml
@ComponentScan(basePackages="com.cg.spring.javaconfig")//same as class in xml

public class ProductConfiguration {

	@Bean//bean decleration
	public Product getProduct()
	{
		Product p=new Product();
		p.setProductName("asus");
		p.setProductPrice(15000.00);
		return p;
	}
	
}
