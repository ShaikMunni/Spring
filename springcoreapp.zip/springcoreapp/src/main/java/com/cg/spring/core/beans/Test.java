package com.cg.spring.core.beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		ApplicationContext a=new ClassPathXmlApplicationContext("aggregation.xml");
		Customer c=a.getBean(Customer.class);
		System.out.println(c);

	}

}
