package com.cg.spring.core.beans;

import java.util.List;
import java.util.Map;

public class Customer {

	private String firstName;
	private String lastName;
	//private Address address;
	//private List<String> list;
	private Map<Integer,Address> map;
	
	public Map<Integer, Address> getMap() {
		return map;
	}


	public void setMap(Map<Integer, Address> map) {
		this.map = map;
	}


	public Customer() {}
	/*public Customer(String firstName, String lastName, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		//this.address = address;
	}*/
	
	
	/*public Customer(String firstName, String lastName, List<Address> list) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		//this.address = address;
		this.list = list;
	}*/
	/*public List<String> getList() {
		return list;
	}
	public void setList(List<String> list) {
		this.list = list;
	}*/
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/*public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}*/
	/*public void show()
	{
		System.out.println(address.toString());
		System.out.println(firstName+" "+lastName);
	}*/


	@Override
	public String toString() {
		return "Customer [firstName=" + firstName + ", lastName=" + lastName + ", map=" + map + "]";
	}
	
	
	
}
