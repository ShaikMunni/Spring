package com.cg.spring.mvc.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.spring.mvc.beans.Employee;
@Service
public interface IEmployeeService {

	List<Employee> viewAll();
	void add(Employee e);
	Employee searchById(int id);
	void delete(int id);
	void update(int i,String n,double s,String m);
}
