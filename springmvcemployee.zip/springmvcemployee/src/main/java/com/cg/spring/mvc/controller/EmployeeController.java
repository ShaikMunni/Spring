package com.cg.spring.mvc.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.spring.mvc.beans.Employee;
import com.cg.spring.mvc.service.IEmployeeService;

@Controller
public class EmployeeController {

	@Autowired
	IEmployeeService service;
	@RequestMapping(value="/view",method=RequestMethod.GET)
	public ModelAndView viewEmp()
	{
		ModelAndView mv=new ModelAndView("/viewall");
		mv.addObject("employees",service.viewAll());
		return mv;
		
	}
	@RequestMapping(value="/adde",method=RequestMethod.GET)
	public ModelAndView addEmp()
	{
		ModelAndView mv=new ModelAndView("/add");
		mv.addObject("command", new Employee());
		return mv;
	}
	@RequestMapping(value="/addemp",method=RequestMethod.POST)
	public String addEmployee(Employee e)
	{
		service.add(e);
		return "redirect:/view";
	}
	@RequestMapping(value="/search",method=RequestMethod.GET)
	public ModelAndView searchEmp(@RequestParam("empId") int id)
	{
		ModelAndView mv=new ModelAndView("/viewone");
		mv.addObject("employee",service.searchById(id));
		return mv;
	}
	@RequestMapping(value="/delete",method=RequestMethod.GET)
	public String deleteEmp(@RequestParam("empId") int id)
	{
		service.delete(id);
		return "redirect:/view";
	}
	@RequestMapping(value="/update",method=RequestMethod.GET)
	public ModelAndView updateEmp(@RequestParam("empId") int id)
	{
		ModelAndView mv=new ModelAndView("/updateemp");
		mv.addObject("emps",service.searchById(id) );
		return mv;
	}
	@RequestMapping(value="/updatee",method=RequestMethod.POST)
	public String updateEmployee(@RequestParam("i") int i,@RequestParam("n") String n,@RequestParam("s") double s,@RequestParam("m") String m)
	{
		service.update(i, n, s, m);
		return "redirect:/view";
		
	}
}
