package com.cg.spring.mvc.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.cg.spring.mvc.beans.Employee;

@Component
public class EmployeeRepoImpl implements IEmployeeRepo{

	
	List<Employee> list=new ArrayList();
	public List<Employee> viewAll() {
		
		return list;
	}
	public void add(Employee e) {
	e.setEmpId(list.size()+1);
	list.add(e);
		
	}
	public Employee searchById(int id) {
		for(Employee l:list)
		{
			if(l.getEmpId()==id)
			{
				return l;
			}
		}
	
		return null;
	}
	public void delete(int id) {
		for(Employee l:list)
		{
			if(l.getEmpId()==id)
			{
				list.remove(l);
			}
		}
		
	}
	public void update(int i,String n,double s,String m) {
		
		for(Employee l:list)
		{
			if(l.getEmpId()==i)
			{
				l.setName(n);
				l.setMail(m);
				l.setSalary(s);
			}
		}/*
		int index=0;
		for(Employee l:list)
		{
		Employee emp=new Employee(id,n,s,m);
		index=list.indexOf(id);
		list.set(index+1,emp);
		}*/
		
	}

}
