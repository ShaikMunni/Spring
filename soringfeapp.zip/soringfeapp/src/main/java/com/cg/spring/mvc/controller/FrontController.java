package com.cg.spring.mvc.controller;

import org.springframework.stereotype.Controller;

@Controller
public class FrontController {

}
