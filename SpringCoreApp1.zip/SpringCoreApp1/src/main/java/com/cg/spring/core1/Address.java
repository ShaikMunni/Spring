package com.cg.spring.core1;

public class Address {

	private String city;
	private String hno;
	
	
	public Address(String city, String hno) {
		super();
		this.city = city;
		this.hno = hno;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getHno() {
		return hno;
	}
	public void setHno(String hno) {
		this.hno = hno;
	}
	@Override
	public String toString() {
		return "Address [city=" + city + ", hno=" + hno + "]";
	}
	
	
}
